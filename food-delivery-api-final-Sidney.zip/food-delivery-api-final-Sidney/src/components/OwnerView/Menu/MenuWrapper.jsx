import React, { Component } from 'react';

class MenuWrapper extends Component {
    constructor(props) {
        super(props);
        this.state = {

        }
    }

    render() {
        return (
            <h1>Owner Menu</h1>
        )
    }
}

export default MenuWrapper;