import React, { Component } from 'react';
import CartCoupons from './CartCoupons'; 
import { Button } from 'antd';
import { Input } from 'antd';
//const { Input } = antd; //for the coupon input

class CartWrapper extends Component {
    constructor(props) {
        super(props);
        this.state = {
            
        }
    }
    

    render() {
        return (
            <h1>Cart
            {/*container for the cart */}
            <div class="cart container" style={{ background: '#fff', padding: '36', minHeight: 280, maxWidth: 1500, justifyContent: 'center', align: 'middle'}}>
            <div class="cart-coupon" Input placehonder="Basic usage" Width="50"  >
        <h5 text-align="left">Coupon (optional)</h5>
        <CartCoupons  />{/*<button type="button" icon="apply">Apply</button>*/}</div>
        <div class="checkout-state"></div>
        <div class="empty-cart"><h4 text-Align="center">Your cart is empty</h4></div>
            </div></h1>
        )
    }
}

export default CartWrapper;