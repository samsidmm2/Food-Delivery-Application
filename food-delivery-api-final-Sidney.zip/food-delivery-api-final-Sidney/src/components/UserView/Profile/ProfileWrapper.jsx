import React, { Component } from 'react';

class ProfileWrapper extends Component {
    constructor(props) {
        super(props);
        this.state = {

        }
    }

    render() {
        return (
            <h1>Profile</h1>
        )
    }
}

export default ProfileWrapper;