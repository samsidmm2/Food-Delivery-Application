import {
    Form, Input, Select, Row, Col, Checkbox, Button, AutoComplete, InputNumber
  } from 'antd';
  import ReactDOM from 'react-dom';
  import React, { Component, TextArea } from 'react';
  const { Option } = Select;
  //const Option = Select.Option;
  //const { TextArea } = Input;


  const AutoCompleteOption = AutoComplete.Option;
  
 /* const states = [{

  }]; */
  
  class ContactForm extends Component {
    state = {
      confirmDirty: false,
      autoCompleteResult: [],
    };
  
    handleSubmit = (e) => {
      e.preventDefault();
      this.props.form.validateFieldsAndScroll((err, values) => {
        if (!err) {
          console.log('Received values of form: ', values);
        }
      });
    }
  
    handleConfirmBlur = (e) => {
      const value = e.target.value;
      this.setState({ confirmDirty: this.state.confirmDirty || !!value });
    }
  
  
  /*  handleWebsiteChange = (value) => {
      let autoCompleteResult;
      if (!value) {
        autoCompleteResult = [];
      } else {
        autoCompleteResult = ['.com', '.org', '.net'].map(domain => `${value}${domain}`);
      }
      this.setState({ autoCompleteResult });
    } */ 
  
    render() {
      const { getFieldDecorator } = this.props.form;
      const { autoCompleteResult } = this.state;
  
      const formItemLayout = {
        labelCol: { span: 4 },
        wrapperCol: { span: 8 },
      };
      const formTailLayout = {
        labelCol: { span: 4 },
        wrapperCol: { span: 8, offset: 4 },
      };

      const prefixSelector = getFieldDecorator('prefix', {
        initialValue: '1',
      })(
        <Select style={{ width: 70 }}>
          <Option value="1">+1</Option>
          <Option value="0">+0</Option>
        </Select>
      );
  
   /*   const websiteOptions = autoCompleteResult.map(website => (
        <AutoCompleteOption key={website}>{website}</AutoCompleteOption>
      )); */
  
      return (
        <Form {...formItemLayout} onSubmit={this.handleSubmit}>

<div class="First Name">
         <Form.Item {...formItemLayout} label="First Name">
          {getFieldDecorator('firstname', {
            rules: [{
              required: true,
              message: 'Please input your first name',
            }],
          })(
            <Input placeholder="Please input your  first name name" />
          )}
        </Form.Item>
</div>

<div class="Last Name">
         <Form.Item {...formItemLayout} label="Last Name">
          {getFieldDecorator('lastname', {
            rules: [{
              required: true,
              message: 'Please input your last name',
            }],
          })(
            <Input placeholder="Please input your last name" />
          )}
        </Form.Item>
</div>

    <div class="email">
          <Form.Item
      
            label="E-mail"
          >
            {getFieldDecorator('email', {
              rules: [{
                type: 'email', message: 'The input is not valid E-mail!',
              }, {
                required: true, message: 'Please input your E-mail!',
              }],
            })(
              <Input />
            )}
          </Form.Item>
</div>

<div class="Citytown">

          <Form.Item
            label="City or town"
          >
            {getFieldDecorator('citytown', {
              rules: [{
                required: true, message: 'Please input your city or town!',
              }],
            })(
              <Input />
            )}
          </Form.Item>
      </div>

      <div class="states">
<Form.Item>
      <Select
    showSearch
    style={{ width: 300 }}
    placeholder="Select your state"
   /* optionFilterProp="children" */
  //  onChange={handleChange}
   // onFocus={handleFocus}
   // onBlur={handleBlur}
   /* filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0} */
  >
                       <option value = "Alabama">Alabama</option>
                        <option value = "Alaska">Alaska</option>
                        <option value = "Arizona">Arizona</option>
                        <option value = "Arkansas">Arkansas</option>
                        <option value = "California">California</option>
                        <option value = "Colorado">Colorado</option>
                        <option value = "Connecticut">Connecticut</option>
                        <option value = "Delaware">Delaware</option>
                        <option value = "Florida">Florida</option>
                        <option value = "Georgia">Georgia</option>
                        <option value = "Hawaii">Hawaii</option>
                        <option value = "Idaho">Idaho</option>
                        <option value = "Illinois">Illinois</option>
                        <option value = "Indiana">Indiana</option>
                        <option value = "Iowa">Iowa</option>
                        <option value = "Kansas">Kansas</option>
                        <option value = "Kentucky">Kentucky</option>
                        <option value = "Louisiana">Louisiana</option>
                        <option value = "Maine">Maine</option>
                        <option value = "Maryland">Maryland</option>
                        <option value = "Massachusetts">Massachusetts</option>
                        <option value = "Michigan">Michigan</option>
                        <option value = "Minnesota">Minnesota</option>
                        <option value = "Mississippi">Mississippi</option>
                        <option value = "Missouri">Missouri</option>
                        <option value = "Montana">Montana</option>
                        <option value = "Nebraska">Nebraska</option>
                        <option value = "Nevada">Nevada</option>
                        <option value = "New Hampshire">New Hampshire</option>
                        <option value = "New Jersey">New Jersey</option>
                        <option value = "New Mexico">New Mexico</option>
                        <option value = "New York">New York</option>
                        <option value = "North Carolina">North Carolina</option>
                        <option value = "North Dakota">North Dakota</option>
                        <option value = "Ohio">Ohio</option>
                        <option value = "Oklahoma">Oklahoma</option>
                        <option value = "Oregon">Oregon</option>
                        <option value = "Pennsylvania">Pennsylvania</option>
                        <option value = "Rhode Island">Rhode Island</option>
                        <option value = "South Carolina">South Carolina</option>
                        <option value = "South Dakota">South Dakota</option>
                        <option value = "Tennessee">Tennessee</option>
                        <option value = "Texas">Texas</option>
                        <option value = "Utah">Utah</option>
                        <option value = "Vermont">Vermont</option>
                        <option value = "Virginia">Virginia</option>
                        <option value = "Washington">Washington</option>
                        <option value = "West Virginia">West Virginia</option>
                        <option value = "Wisconsin">Wisconsin</option>
                        <option value = "Wyoming">Wyoming</option>
  </Select>,
    </Form.Item>  
      </div>

      <div class="Zip Code">
<Form.Item
          label="Zip Code"
        >
          {getFieldDecorator('zipcode', {
            rules: [{ required: true, message: 'Please input your zip code!' }],
          })(
            <InputNumber addonBefore={prefixSelector} style={{ width: '100%' }}/>
            
          )}
        </Form.Item>
</div>


<div class="phonenumber">
<Form.Item
          label="Phone Number"
        >
          {getFieldDecorator('phone', {
            rules: [{ required: true, message: 'Please input your phone number!' }],
          })(
            <Input addonBefore={prefixSelector} style={{ width: '100%' }} />
          )}
        </Form.Item>
</div>
    
            <div class="message">
            <Form.Item label="message"
            >
             {getFieldDecorator('message', {
            rules: [{ required: true, message: 'Please input your concern! No personal info' }],
          })(
            <TextArea addonBefore={prefixSelector} style={{ width: '100%' }} />
          )}
            </Form.Item>
            </div>

      <Form.Item
      /*    label="Website"*/
          >
          </Form.Item> 

          <Form.Item
            label="Captcha"
            extra="We must make sure that your are a human."
          >
            <Row gutter={8}>
              <Col span={12}>
                {getFieldDecorator('captcha', {
                  rules: [{ required: true, message: 'Please input the captcha you got!' }],
                })(
                  <Input />
                )}
              </Col>
              <Col span={12}>
                <Button>Get captcha</Button>
              </Col>
            </Row>
          </Form.Item>
          <Form.Item>
       {/*    <Form.Item {...tailFormItemLayout}>
            {getFieldDecorator('agreement', {
              valuePropName: 'checked',
            })(
              <Checkbox>I have read the <a href="">agreement</a></Checkbox>
            )}
          </Form.Item>
            <Form.Item {...tailFormItemLayout} > */}
            <Button type="primary" htmlType="submit">Submit</Button>
          </Form.Item>
        </Form>
      );
    }
  }
  
  //const WrappedContactForm = Form.create({ name: 'contactus' })(ContactForm);
  
 // ReactDOM.render(<WrappedContactForm />);

 export default ContactForm