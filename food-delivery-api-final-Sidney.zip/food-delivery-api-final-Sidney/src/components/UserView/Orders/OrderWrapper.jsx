import React, { Component } from 'react';

class OrderWrapper extends Component {
    constructor(props) {
        super(props);
        this.state = {

        }
    }

    render() {
        return (
            <h1>Order</h1>
        )
    }
}

export default OrderWrapper;
