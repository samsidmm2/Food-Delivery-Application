import React, { Component } from 'react';

class DriverPastOrderWrapper extends Component {
    constructor(props) {
        super(props);
        this.state = {

        }
    }

    render() {
        return (
            <h1>Driver Past Orders</h1>
        )
    }
}

export default DriverPastOrderWrapper;