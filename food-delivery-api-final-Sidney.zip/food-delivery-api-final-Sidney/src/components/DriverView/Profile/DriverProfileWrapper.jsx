import React, { Component } from 'react';

class DriverProfileWrapper extends Component {
    constructor(props) {
        super(props);
        this.state = {
            
        }
    }

    render() {
        return (
            <h1>Driver Profile</h1>
        )
    }
}

export default DriverProfileWrapper;