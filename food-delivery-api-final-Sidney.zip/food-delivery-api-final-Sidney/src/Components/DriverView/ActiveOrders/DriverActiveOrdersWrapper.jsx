import React, { Component } from 'react';

class DriverActiveOrderWrapper extends Component {
    constructor(props) {
        super(props);
        this.state = {

        }
    }

    render() {
        return (
            <h1>Driver Active Orders</h1>
        )
    }
}

export default DriverActiveOrderWrapper;