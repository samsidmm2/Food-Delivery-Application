import React, { Component } from 'react';
import { Input } from 'antd';
import Search from 'antd/lib/transfer/search';
const Click = Input.Click;


class CartWrapper extends Component {
    constructor(props) {
        super(props);
        this.state = {

        }
    }

    render() {
        return (

            <Input.Search
                placeholder="Enter coupon"
                enterButton="Enter"
                size="small"
                onClick={value => console.log(value)}
            />
        )
    }
}

export default CartWrapper;