import React, { Component } from 'react';
import { withRouter } from 'react-router';
import { Table, Divider } from 'antd';


//   const { Table, Divider  } = antd;
const { columns, data } = Table;

class UserMenu extends Component {
    constructor(props) {
        super(props);
        this.state = {

        }
    }

    
    
    
    
    render() {

        const data = [{
            key: 'cheeseburger',
            itemName: 'Cheeseburger',
            description: 'Your juicy burger burger',
            price: 3.750,
            cartAdd: 'Add to Cart',
            width: 900,
        }, 
        {
            key: 'hamburger',
            itemName: 'Hamburger',
            description: 'Your juicy burger burger',
            price: 2.50,
            cartAdd: 'Add to Cart',
            width: 900,
        },
        {
            key: 'taco',
            itemName: 'Taco',
            description: 'Your unique Taco',
            price: 3.00,
            cartAdd: 'Add to Cart',
            width: 900,
        },
        {
            key: 'chilli',
            itemName: 'Chilli',
            description: 'Your spicy chilli ',
            price: 3.25,
            cartAdd: 'Add to Cart',
            width: 900,
        },
        {
            key: 'icecream',
            itemName: 'Ice Cream',
            description: 'Your creamy Ice Cream ',
            price: 3.25,
            cartAdd: 'Add to Cart',
            width: 900,
        },
    ];
        const columns = [
            {
                title: 'Item Name',  dataIndex: 'itemName', key: 'item name', fixed: 'left', width: 900,
            },
            {
                title: 'Description',  dataIndex: 'description', key: 'description', fixed: 'left', width: 900,
            },
            { title: 'Price (USD)',  dataIndex: 'price', key: 'price', fixed: 'left', width: 900, },
            {
                title: 'Action',
                key: 'action',
                fixed: 'left',
                width: 900,
                render: (text, record) => (
                    <a href="javascript:;">Add To Cart {record.name}</a>
                ),
            },
        ];


            return (
                <div className="user-menu">
                    <h1>Jim's Menu</h1>
                    <div className="jim-cheese">


                        <Table style={{textAlign: "center", justifyContent: "center", alignContent: 'center', alignItems: "center"}} columns={columns} dataSource={data}  />
                    </div>
                </div>
            )
        }
    }

    export default withRouter(UserMenu);