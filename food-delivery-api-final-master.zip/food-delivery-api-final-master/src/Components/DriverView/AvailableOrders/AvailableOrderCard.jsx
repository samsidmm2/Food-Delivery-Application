import React, { Component } from 'react';
import { Button, Card } from 'antd';


const buttonStyle={
size:"small",
flexDirection: 'row',
AlignItems: 'right',

}

const content = 'this is where all your order information goes.';
const Price = '$$';
const Status = 'Available for Pickup'


class DriverAvailableOrderCard extends Component {
  constructor(props) {
    super(props);
    this.state = {

    }
  }


  render() {

    return (

      <Card size ='small' title = 'Payton Karno' extra ={<Button style={buttonStyle} type = 'primary'>Accept Order</Button>}>
      
      <div style={{direction: 'flex', flexDirection: 'row'}}>
      <h3>Contents:</h3><p>{content}</p>
      </div>

      <h3>Status: </h3><p>{Status}</p>
      
      <h3>Price: </h3><p>{Price}</p>
    </Card>  

        
    )
  }
}

export default DriverAvailableOrderCard;